Tags: [[Email]] [[Self-Development]] - [[Perfectionism]] 
Author: [[Seth Godin]] 

## Highlights:

One option is to embrace your failure. To have your tantrum, to become bereft, to wallow in how unfair the world is. No sense messing up a perfect moment of imperfection.

The other option is to put some effort into making an imperfect situation a little less imperfect. Perhaps, with some distance, it might even be a lot less imperfect, or even better than you were hoping for in the first place.

Imperfect is a chance for contribution, connection and improvisation. It’s a chance to see the humanity behind the moment you were spending so much energy creating.

The alternative to perfect might be better.