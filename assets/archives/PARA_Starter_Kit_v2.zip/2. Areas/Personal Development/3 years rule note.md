From Matt D'avella video

You need to give yourself the opportunity to succeed and you need to realize it's going to take longer than you thought

Social media make it look instant but it's a lie. They make us expect things to be quick (delivery, search, news)

Patience and persistence is what's important

Create a big long term goal (3 years) so failure looks smaller, because of the time scale

Dedication for the long run
It change how you look at risk

The biggest risk is status quo

We almost always get a 2nd chance anyway

Give full effort and go forward for 3 years

Building things take time and commitment

2 days rule for the short term and 3 years for the long term

The long game idea #Research
