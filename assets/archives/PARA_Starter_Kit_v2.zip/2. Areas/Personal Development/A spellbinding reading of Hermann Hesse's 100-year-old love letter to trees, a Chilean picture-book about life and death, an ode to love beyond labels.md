Tags: [[Email]] [[Self-Development]] - [[Emotions]] [[Labels]] [[Naming]]
Author: [[Maria Popova]]

## Highlights:

The human heart is an ancient beast that roars and purrs with the same passions, whatever labels we may give them. We are so anxious to classify and categorize, both nature and human nature. It is a beautiful impulse — to contain the infinite in the finite, to wrest order from the chaos — but it is also a limiting one: In naming things, we often come to mistake the names for the things themselves. The labels we give to the loves of which we are capable — varied and vigorously transfigured from one kind into another and back again — cannot begin to contain the richness of feeling that can flow between two hearts and the bodies that contain them.