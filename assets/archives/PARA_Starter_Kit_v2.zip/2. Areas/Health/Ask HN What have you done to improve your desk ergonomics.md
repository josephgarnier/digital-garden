https://news.ycombinator.com/item?id=21623319

Taking breaks is important even if it just means you get coffee in
smaller serving sizes.

There are a couple things that matter in ergonomics, mainly that your
chair is at a height where you can set your feet flat on the floor
comfortably, and that your forearms are the same height as the desk.
