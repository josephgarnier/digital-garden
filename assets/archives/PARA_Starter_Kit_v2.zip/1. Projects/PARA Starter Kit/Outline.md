## Start here
- General how-this-work
- What to expect
- How to start
## Definition 
- ![[PARA Notes#Definitions]]
## Methodology
- Actionnability
- Fluidity
- Project based
- Constraint
## Workflow
- ![[PARA Notes#Workflow]]
## Next steps
- Tiago's blog
- Discord