Tags: [[Podcast]] [[Community]] - [[Audience]]
Podcast: [[The Future Belongs to Creators]] 

## Highlights:

What is an audience, how do you find them
	- People who want to hear from you and would miss you if you didn't show up
	- People who want follow you around even when you jump off and change

Audience building = Community Building

Kevin Kelly - 1000 true fans principles

That makes it so you won't need to make a lot of money on each of them to make a very good living (100$/years -= 100k / years revenue )

To start pick the friends, the people you know who would be interesting in the topics
	- Text them or connect with them
	- Some will say no and you need to get used to it too
	- Habit skill of rejection and learn how to make the ask

Show up consistantly no matter the result

You don't control the result but you control the process

If you're one step ahead of your audience then everything you learn as value for them to learn
		- Concept of Leading learner

People wants connection and to get connection you need to tell the full story and be authentic

People connect the most when you're authentic with your story, the mistake you made, the errors, the problems

Tell the story or teach and just switch between the 2 as you see fit