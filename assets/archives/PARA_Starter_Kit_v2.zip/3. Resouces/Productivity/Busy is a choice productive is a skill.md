https://seths.blog/2019/11/busy-is-a-choice-productive-is-a-skill/

Productivity, on the other hand, has little to do with busy. 
Productivity requires bringing soft skills (real skills) to the table in service of the generous work you seek to do. 
Productivity is learned. And productivity takes guts.